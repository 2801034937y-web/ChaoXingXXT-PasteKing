(() => {
  "use strict";

  const CFG = {
    mode: "type",
    charDelay: 0,
    fireKeys: true,
    clearFirst: true,
    highlight: true
  };

  const LS_KEY = "__dsh_last_text__";

  const tag = "%c[粘贴王]";
  const stl = "color:#fff;background:#0a84ff;padding:1px 5px;border-radius:3px";
  const log = (...a) => console.log(tag, stl, ...a);
  const warn = (...a) => console.warn(tag, stl, ...a);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function allDocs() {
    const out = [{ doc: document, frame: null }];
    for (let i = 0; i < out.length && i < 20; i++) {
      let frames = [];
      try { frames = out[i].doc.querySelectorAll("iframe"); } catch (e) { continue; }
      for (const f of frames) {
        try { if (f.contentDocument) out.push({ doc: f.contentDocument, frame: f }); } catch (e) {}
      }
    }
    return out;
  }

  function visible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 40 || r.height < 16) return false;
    const s = (el.ownerDocument.defaultView || window).getComputedStyle(el);
    if (s.display === "none" || s.visibility === "hidden" || s.opacity === "0") return false;
    return true;
  }

  function pickEditor() {
    const cands = [];
    for (const { doc: d, frame } of allDocs()) {
      let nodes = [];
      try {
        nodes = d.querySelectorAll('[contenteditable="true"], textarea');
      } catch (e) { continue; }
      for (const el of nodes) {
        const isCE = el.getAttribute && el.getAttribute("contenteditable") === "true";
        const isTA = el.tagName === "TEXTAREA";
        if (!isCE && !isTA) continue;
        if (!visible(el)) continue;

        const r = el.getBoundingClientRect();
        let score = r.width * r.height;
        const idc = (el.id + " " + el.className + " " +
          (el.closest ? (el.closest("[id],[class]") ? el.closest("[id],[class]").className : "") : ""))
          .toLowerCase();
        if (/answer|homework|work|content|editor|ueditor|uedit|cke|tinymce|submit/.test(idc)) score *= 6;
        if (/search|login|user|name|phone|comment|souti|tiku/.test(idc)) score *= 0.02;

        if (frame) {
          const fid = ((frame.id || "") + " " + (frame.className || "")).toLowerCase();
          if (/ueditor|edui/.test(fid)) score *= 20;
          else score *= 0.3;
        }

        if (el.readOnly || el.disabled) continue;
        cands.push({ el, score, kind: isCE ? "contenteditable" : "textarea", doc: d });
      }
    }
    cands.sort((a, b) => b.score - a.score);
    return cands;
  }

  function caretToEnd(el, doc) {
    try {
      const sel = doc.getSelection ? doc.getSelection() : window.getSelection();
      if (!sel) return;
      const r = doc.createRange();
      r.selectNodeContents(el);
      r.collapse(false);
      sel.removeAllRanges();
      sel.addRange(r);
    } catch (e) {}
  }

  function fireKey(el, type, ch, code) {
    if (!CFG.fireKeys) return;
    try {
      el.dispatchEvent(new KeyboardEvent(type, {
        key: ch, code: ch, keyCode: code, which: code,
        charCode: type === "keypress" ? code : 0,
        bubbles: true, cancelable: true, composed: true
      }));
    } catch (e) {}
  }

  function clearEditor(el, kind, doc) {
    try {
      if (kind === "contenteditable") {
        el.focus();
        const sel = doc.getSelection ? doc.getSelection() : window.getSelection();
        const r = doc.createRange();
        r.selectNodeContents(el);
        sel.removeAllRanges();
        sel.addRange(r);
        doc.execCommand("delete", false, null);
        if (el.textContent.trim().length) el.innerHTML = "";
      } else {
        const setter = Object.getOwnPropertyDescriptor(
          el.ownerDocument.defaultView.HTMLTextAreaElement.prototype, "value"
        ).set;
        setter.call(el, "");
      }
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } catch (e) {}
  }

  function currentLength(el, kind) {
    const t = kind === "contenteditable" ? el.innerText : el.value;
    return (t || "").replace(/\s/g, "").length;
  }

  async function fill(cand, TEXT) {
    const { el, kind } = cand;
    const doc = el.ownerDocument || document;

    if (CFG.clearFirst) clearEditor(el, kind, doc);
    el.focus();
    if (kind === "contenteditable") caretToEnd(el, doc);

    if (CFG.mode === "paste") {
      const ok = (() => {
        try { return doc.execCommand("insertText", false, TEXT); } catch (e) { return false; }
      })();
      if (!ok) {
        if (kind === "contenteditable") {
          el.innerHTML = TEXT.split(/\n+/).map((p) => "<p>" + p + "</p>").join("");
        } else {
          const setter = Object.getOwnPropertyDescriptor(
            el.ownerDocument.defaultView.HTMLTextAreaElement.prototype, "value"
          ).set;
          setter.call(el, TEXT);
        }
      }
    } else {
      const chars = Array.from(TEXT);
      for (let i = 0; i < chars.length; i++) {
        const ch = chars[i];
        if (ch === "\n") {
          fireKey(el, "keydown", "Enter", 13);
          try { doc.execCommand("insertParagraph", false, null) || doc.execCommand("insertLineBreak", false, null); }
          catch (e) { try { doc.execCommand("insertHTML", false, "<br>"); } catch (e2) {} }
          fireKey(el, "keyup", "Enter", 13);
        } else {
          const code = ch.charCodeAt(0);
          fireKey(el, "keydown", ch, 229);
          fireKey(el, "keypress", ch, code);
          let ok = false;
          try { ok = doc.execCommand("insertText", false, ch); } catch (e) { ok = false; }
          if (!ok) {
            if (kind === "contenteditable") el.appendChild(doc.createTextNode(ch));
            else el.value += ch;
            el.dispatchEvent(new InputEvent("input", { bubbles: true, data: ch, inputType: "insertText" }));
          }
          fireKey(el, "keyup", ch, 229);
        }
        if (CFG.charDelay) await sleep(CFG.charDelay);
      }
    }

    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    try {
      if (window.jQuery) window.jQuery(el).trigger("input").trigger("change").trigger("keyup").trigger("blur");
    } catch (e) {}

    return currentLength(el, kind);
  }

  async function run(text) {
    const want = String(text || "").replace(/\s/g, "").length;
    if (!want) return { ok: false, msg: "内容是空的" };

    const cands = pickEditor();
    if (!cands.length) {
      return {
        ok: false,
        msg: "没找到答题框。先点开作业编辑界面，用鼠标点一下输入框，再试一次。",
        frames: Array.from(document.querySelectorAll("iframe"))
          .map((f) => "#" + (f.id || "?") + (f.className ? "." + String(f.className).split(" ")[0] : ""))
      };
    }

    const target = cands[0];
    log("找到 " + cands.length + " 个候选框，选中：" + target.kind, target.el);

    if (CFG.highlight) {
      target.el.style.outline = "3px solid #ff3b30";
      target.el.style.outlineOffset = "2px";
    }

    const n = await fill(target, String(text));
    await sleep(200);
    const final = currentLength(target.el, target.kind);
    const ok = final >= want * 0.9;
    if (ok) log("✅ 成功：答题框里现在有 " + final + " 个字（目标 " + want + "）");
    else warn("⚠️ 只写进去 " + final + " / " + want + " 个字。把 CFG.mode 改成 \"paste\" 再试。");

    return { ok, chars: final, want, target: target.el };
  }

  function buildPanel() {
    const old = document.getElementById("__dsh_fill_host__");
    if (old) old.remove();

    const host = document.createElement("div");
    host.id = "__dsh_fill_host__";
    host.style.cssText = "position:fixed;right:18px;bottom:18px;z-index:2147483647;";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        *{box-sizing:border-box;font-family:"Microsoft YaHei",system-ui,sans-serif}
        .p{position:relative;width:340px;max-width:calc(100vw - 24px);background:#fff;border:1px solid #d0d5dd;
           border-radius:12px;box-shadow:0 12px 32px rgba(16,24,40,.18),0 2px 6px rgba(16,24,40,.08);
           overflow:hidden;color:#1f2937;transition:width .18s ease;animation:pk-in .18s ease-out}
        @keyframes pk-in{from{opacity:0;transform:translateY(6px) scale(.985)}to{opacity:1;transform:none}}
        .hd{display:flex;justify-content:space-between;align-items:center;padding:10px 12px;
            background:linear-gradient(180deg,#1a8cff,#0a84ff);color:#fff;font-size:13px;
            font-weight:600;cursor:grab;user-select:none}
        .hd:active{cursor:grabbing}
        .t{display:flex;align-items:center;gap:6px;letter-spacing:.3px}
        .btns{display:flex;gap:4px}
        .btns span{width:22px;height:22px;display:flex;align-items:center;justify-content:center;
                   border-radius:6px;font-size:13px;line-height:1;cursor:pointer;opacity:.92;
                   transition:background .15s}
        .btns span:hover{background:rgba(255,255,255,.22);opacity:1}
        .bd{display:block}
        .p.min{width:210px}
        .p.min .bd{display:none}
        textarea{width:100%;height:120px;border:0;border-bottom:1px solid #eaecf0;padding:12px;
                 font-size:13px;line-height:1.65;resize:none;outline:none;display:block;
                 color:inherit;background:transparent}
        textarea:focus{background:#fbfdff}
        .ft{display:flex;justify-content:space-between;align-items:center;padding:10px 26px 10px 12px;background:#fafbfc}
        .c{font-size:12px;color:#667085;font-variant-numeric:tabular-nums}
        button{border:0;border-radius:8px;padding:8px 18px;font-size:13px;font-weight:600;
               cursor:pointer;background:#0a84ff;color:#fff;transition:background .15s,transform .06s}
        button:hover{background:#0873dd}
        button:active{transform:scale(.98)}
        button:disabled{background:#a9c7ef;cursor:default;transform:none}
        .m{padding:0 12px;font-size:12px;line-height:1.55;max-height:0;overflow:hidden;
           opacity:0;transition:max-height .18s ease,opacity .18s ease,padding .18s ease}
        .m.s,.m.e{max-height:84px;padding-bottom:10px;opacity:1}
        .m.s{color:#0a7d33}
        .m.e{color:#c0392b}
        .rz{position:absolute;right:3px;bottom:3px;width:16px;height:16px;cursor:ns-resize;
            display:flex;align-items:flex-end;justify-content:flex-end;z-index:2;opacity:.75}
        .rz i{display:block;width:12px;height:12px;
              background-image:repeating-linear-gradient(135deg,#b9c0cc 0 1.5px,transparent 1.5px 4.5px);
              clip-path:polygon(100% 0,100% 100%,0 100%)}
        .rz:hover{opacity:1}
        .rz:hover i{background-image:repeating-linear-gradient(135deg,#0a84ff 0 1.5px,transparent 1.5px 4.5px)}
        .ball{position:fixed;right:18px;bottom:18px;width:48px;height:48px;border-radius:50%;
              background:linear-gradient(145deg,#1a8cff,#0a84ff);color:#fff;font-size:15px;
              font-weight:700;display:none;align-items:center;justify-content:center;cursor:pointer;
              user-select:none;box-shadow:0 6px 18px rgba(10,132,255,.4);
              transition:transform .15s,box-shadow .15s}
        .ball:hover{transform:translateY(-2px) scale(1.04);box-shadow:0 10px 24px rgba(10,132,255,.5)}
      </style>
      <div class="p">
        <div class="hd">
          <span class="t">粘贴王</span>
          <span class="btns"><span class="min" title="折叠">—</span><span class="x" title="关闭">✕</span></span>
        </div>
        <div class="bd">
          <textarea placeholder="先粘贴到这里，然后点「填入」…"></textarea>
          <div class="ft"><span class="c">0 字</span><button class="go">填 入</button></div>
          <div class="m"></div>
        </div>
        <span class="rz" title="拖动调整输入框高度（双击复位）"><i></i></span>
      </div>
      <div class="ball" title="打开粘贴王">粘</div>`;

    const $ = (s) => root.querySelector(s);
    const p = $(".p"), ball = $(".ball"), ta = $("textarea"), cnt = $(".c"), msg = $(".m"), go = $("button.go");
    const LS_TEXT = "__dsh_last_text__";
    const LS_POS = "__pasteking_pos__";
    let msgTimer = 0;

    const refresh = () => { cnt.textContent = ta.value.replace(/\s/g, "").length + " 字"; };

    function showMsg(cls, text, autoHide) {
      msg.className = "m " + cls;
      msg.textContent = text;
      clearTimeout(msgTimer);
      if (autoHide) msgTimer = setTimeout(() => { msg.className = "m"; }, 4000);
    }

    function clampPos(l, t) {
      const r = p.getBoundingClientRect();
      const maxL = Math.max(8, window.innerWidth - r.width - 8);
      const maxT = Math.max(8, window.innerHeight - r.height - 8);
      return { l: Math.min(Math.max(8, l), maxL), t: Math.min(Math.max(8, t), maxT) };
    }

    function setPos(l, t) {
      const c = clampPos(l, t);
      host.style.right = "auto";
      host.style.bottom = "auto";
      host.style.left = c.l + "px";
      host.style.top = c.t + "px";
    }

    function openPanel() {
      p.style.display = "block";
      ball.style.display = "none";
      if (host.style.left) { const r = p.getBoundingClientRect(); setPos(r.left, r.top); }
    }

    function closePanel() {
      p.style.display = "none";
      ball.style.display = "flex";
    }

    $(".x").addEventListener("click", closePanel);
    ball.addEventListener("click", openPanel);

    const minBtn = $(".min");
    minBtn.addEventListener("click", () => {
      p.classList.toggle("min");
      const on = p.classList.contains("min");
      minBtn.textContent = on ? "▢" : "—";
      minBtn.title = on ? "展开" : "折叠";
      if (!on && host.style.left) { const r = p.getBoundingClientRect(); setPos(r.left, r.top); }
    });

    try { const last = localStorage.getItem(LS_TEXT); if (last) ta.value = last; } catch (e) {}

    refresh();
    ta.addEventListener("input", refresh);
    ta.addEventListener("paste", () => setTimeout(refresh, 0));
    ta.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); go.click(); }
    });

    // 自定义输入框高度：拖右下角手柄，双击复位
    const LS_H = "__pasteking_h__";
    const rz = $(".rz");
    const MIN_H = 72;
    const maxH = () => Math.max(MIN_H + 24, Math.min(window.innerHeight * 0.65, 460));
    const clampH = (h) => Math.min(Math.max(MIN_H, h), maxH());
    const setH = (h) => { ta.style.height = clampH(h) + "px"; };
    try {
      const savedH = parseInt(localStorage.getItem(LS_H) || "0", 10);
      if (savedH) setH(savedH);
    } catch (e) {}
    let rzY = 0, rzH = 0, rzOn = false;
    rz.addEventListener("pointerdown", (e) => {
      rzOn = true;
      rzY = e.clientY;
      rzH = ta.getBoundingClientRect().height;
      try { rz.setPointerCapture(e.pointerId); } catch (err) {}
      e.preventDefault();
    });
    rz.addEventListener("pointermove", (e) => {
      if (!rzOn) return;
      setH(rzH + (e.clientY - rzY));
      if (host.style.left) { const r = p.getBoundingClientRect(); setPos(r.left, r.top); }
    });
    const endRz = (e) => {
      if (!rzOn) return;
      rzOn = false;
      try { rz.releasePointerCapture(e.pointerId); } catch (err) {}
      try { localStorage.setItem(LS_H, String(Math.round(ta.getBoundingClientRect().height))); } catch (err) {}
    };
    rz.addEventListener("pointerup", endRz);
    rz.addEventListener("pointercancel", endRz);
    rz.addEventListener("dblclick", () => {
      ta.style.height = "120px";
      try { localStorage.setItem(LS_H, "120"); } catch (e) {}
    });

    go.addEventListener("click", async () => {
      const text = ta.value;
      if (!text.trim()) {
        showMsg("e", "⚠️ 先把要填入的文字粘贴到上方输入框");
        ta.focus();
        return;
      }
      go.disabled = true;
      go.textContent = "填入中…";
      msg.className = "m";
      try {
        const r = await run(text);
        if (r.ok) {
          try { localStorage.setItem(LS_TEXT, text); } catch (e) {}
          showMsg("s", "✅ 已填入 " + r.chars + " 字，请通读一遍再手动点【提交】", true);
        } else {
          showMsg("e", "⚠️ " + r.msg + (r.frames ? "（iframe: " + r.frames.join(" ") + "）" : ""));
        }
      } catch (e) {
        showMsg("e", "⚠️ 出错：" + (e && e.message ? e.message : e));
      } finally {
        go.disabled = false;
        go.textContent = "填 入";
      }
    });

    const hd = $(".hd");
    let sx = 0, sy = 0, ox = 0, oy = 0, dragging = false;
    hd.addEventListener("mousedown", (e) => {
      if (e.target.closest(".btns")) return;
      const r = p.getBoundingClientRect();
      dragging = true;
      sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top;
      host.style.right = "auto";
      host.style.bottom = "auto";
      host.style.left = ox + "px";
      host.style.top = oy + "px";
      e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      setPos(ox + (e.clientX - sx), oy + (e.clientY - sy));
    });
    window.addEventListener("mouseup", () => {
      if (!dragging) return;
      dragging = false;
      const r = p.getBoundingClientRect();
      try { localStorage.setItem(LS_POS, JSON.stringify({ l: Math.round(r.left), t: Math.round(r.top) })); } catch (e) {}
    });
    window.addEventListener("resize", () => {
      setH(ta.getBoundingClientRect().height);
      if (!host.style.left) return;
      const r = p.getBoundingClientRect();
      setPos(r.left, r.top);
    });

    document.documentElement.appendChild(host);
    try {
      const pos = JSON.parse(localStorage.getItem(LS_POS) || "null");
      if (pos && typeof pos.l === "number" && typeof pos.t === "number") setPos(pos.l, pos.t);
    } catch (e) {}

    log("粘贴王已就绪（右下角）。粘贴文字 → 点「填入」。");
    return host;
  }
  window.__dshFill = { run, pickEditor, CFG, panel: buildPanel };
  buildPanel();
})();
